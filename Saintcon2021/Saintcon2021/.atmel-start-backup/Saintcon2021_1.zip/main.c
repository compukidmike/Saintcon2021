#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		if(gpio_get_pin_level(PIN_PA27)){
			pwm_set_parameters(&PWM_0, 10000, 5000);
		} else {
			pwm_set_parameters(&PWM_0, 10000, 0);
		}
	}
}
